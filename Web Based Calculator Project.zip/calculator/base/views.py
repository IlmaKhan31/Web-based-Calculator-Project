
from django.http import HttpResponse
from django.shortcuts import render
# from .forms import CalculatorForm


def index(request):
    return render(request, 'calculator/index.html')

def calculate(request):
    if request.method == 'POST':
        num1 = float(request.POST['num1'])
        num2 = float(request.POST['num2'])
        operation = request.POST['operation']

        if operation == 'add':
            result = num1 + num2
        elif operation == 'subtract':
            result = num1 - num2
        elif operation == 'multiply':
            result = num1 * num2
        elif operation == 'divide':
            result = num1 / num2
        else:
            result = 'Invalid Operation'

        return render(request, 'calculator/index.html', {'result': result})
    # return render(request, 'calculator/index.html', {'form': form})
    return render(request, 'calculator/index.html', {'result': ''})


def home(request):
    context={}
    return HttpResponse(request,'base/calculator.html',context)
def profile(request):  
    return HttpResponse('profile page')
