from django import forms

class CalculatorForm(forms.Form):
    first_number = forms.FloatField(label='First Number')
    second_number = forms.FloatField(label='Second Number')
    operation = forms.ChoiceField(choices=[
        ('add', 'Add'),
        ('subtract', 'Subtract'),
        ('multiply', 'Multiply'),
        ('divide', 'Divide')
    ])
